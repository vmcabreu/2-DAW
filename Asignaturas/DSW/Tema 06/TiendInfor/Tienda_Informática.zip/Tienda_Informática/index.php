<?php
    declare(strict_types = 1); 
    header("Location: ./Controlador/Productos.php");
?>