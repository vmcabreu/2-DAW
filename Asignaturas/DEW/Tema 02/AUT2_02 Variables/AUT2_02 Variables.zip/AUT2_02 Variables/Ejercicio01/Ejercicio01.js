let numero = 15;
let potencia= 15;

for (let i = 1; i < 6; i++) {
    potencia *= numero;
    
}

document.getElementById("resultado1").innerHTML = potencia;
