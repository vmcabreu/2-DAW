for (let i = 0, j = 20; i < 9 && j > -1; i++, j-=3) {
    console.log(i + "," + j);

}

document.getElementById("resultado10").innerHTML = "Los resultados estan en la consola";









