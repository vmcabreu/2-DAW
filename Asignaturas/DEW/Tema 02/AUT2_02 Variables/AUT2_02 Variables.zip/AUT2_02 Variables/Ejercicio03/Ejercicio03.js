let itinerante1;
let itinerante2;
console.log("Ejercicio 05:");
for ( itinerante1 = 0; itinerante1 < 10; itinerante1++) {
    for (itinerante2 = 0; itinerante2 < 10; itinerante2++) {
        console.log("Itinerante 1: "+itinerante1+"  Itinerante2: "+itinerante2);
    }
}



document.getElementById("resultado3").innerHTML = "Los resultados estan en la consola";