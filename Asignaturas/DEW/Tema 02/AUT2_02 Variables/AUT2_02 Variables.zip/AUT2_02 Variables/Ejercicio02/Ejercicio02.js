let suma = 0;

for (let i = 1; i <= 10; i++) {
    suma += i;
}

document.getElementById("resultado2").innerHTML = suma;