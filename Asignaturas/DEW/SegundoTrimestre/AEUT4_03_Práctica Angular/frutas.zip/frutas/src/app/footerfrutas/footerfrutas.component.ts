import { Component } from '@angular/core';

@Component({
  selector: 'app-footerfrutas',
  templateUrl: './footerfrutas.component.html',
  styleUrls: ['./footerfrutas.component.css']
})
export class FooterfrutasComponent {
  copyright='Angular @ 2022'
}
