import { Component } from '@angular/core';

@Component({
  selector: 'app-bodyfrutas',
  templateUrl: './bodyfrutas.component.html',
  styleUrls: ['./bodyfrutas.component.css']
})
export class BodyfrutasComponent {
  
}
